#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :1.0    
#usage		     :

a=0

 while
 [ $a -lt 10 ]
do   
    echo $a   
    a=`expr $a + 1`
done
