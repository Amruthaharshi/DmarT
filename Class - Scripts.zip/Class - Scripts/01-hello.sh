#!/bin/bash      
#title           : 
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :2.0    
#usage		     :sh hello.sh
#CopyRights      : Mithun Technologies
#Contact         : 9980923226

echo "Hello Guys"
echo "Welcome to ShellScript"
echo "This is the first shell script example !!"
echo "Today date is"
date
echo "Shellscript is very easy"



