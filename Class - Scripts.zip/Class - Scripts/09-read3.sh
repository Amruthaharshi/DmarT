#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :1.0    
#usage		     :


echo 'Enter DevOps Tools: '
read -a devopstools
echo "The DevOps Tools which you entered are: " ${devopstools[0]},${devopstools[1]},${devopstools[2]},${devopstools[3]},${devopstools[4]}

