#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :1.0    
#usage		     :
 

greetfn(){

echo "Welcome to Shell script! "

}

echo "Calling greetfn() "


greetfn