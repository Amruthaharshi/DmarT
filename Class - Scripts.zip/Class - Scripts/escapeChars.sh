#NewLine
echo -e $'\n'
echo "This will print
as two lines."
echo -e "This will print \
as one line."
#Vertical Tab
echo -e "\v\v" 
#Makes beep sound
echo -e $'\a'  
#Horizantal Tab
echo -e $'\t' 'Hello Guys'