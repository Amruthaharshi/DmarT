#!/bin/bash      
#title           :
#description     :
#author		     :Mithun Reddy Lacchannagari
#date            :08112012
#version         :1.0    
#usage		     :


read -p 'Enter User Name ' userName
read -sp 'Enter the password ' password

echo '      '
echo 'You entered username is: '$userName
echo 'You entered password is: '$password


