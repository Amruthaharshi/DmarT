#!/bin/bash      
#title           :comments.sh
#description     :
#author		     :Mithun Reddy L
#date            :08112012
#version         :1.0    
#usage		     :sh comments.sh


echo "SHELL is: " $SHELL
echo "BASH_VERSION is: " $BASH_VERSION
echo 'HISTSIZE is: '$HISTSIZE
echo 'SSH_CLIENT is: '$SSH_CLIENT
